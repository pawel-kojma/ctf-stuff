def llllIIIllllllIIlllIIlllllIII(lllllllllllllllllllllllllIII):
    llllllllllllllllllllllllllII = ""
    for lllllllllllllllllllllllllllI in lllllllllllllllllllllllllIII:
        llllllllllllllllllllllllllII += IIIIIIIlllllllllllllllllllll(IIIIIIllllllllllllllllllllll(IIIIIIIlllllllllllllllllllll(IIIIIIllllllllllllllllllllll(IIIIIIIlllllllllllllllllllll(IIIIIIllllllllllllllllllllll(lllllllllllllllllllllllllllI)^IIIIIIllllllllllllllllllllll('b')))^IIIIIIllllllllllllllllllllll('a')))^IIIIIIllllllllllllllllllllll('b'))
    return llllllllllllllllllllllllllII[-1::-1][::-1]
IIIIIIllllllllllllllllllllll = ord
def lllllIIllllllIIlllIIlllllIII(lllllllllllllllllllllllllIII):
    llllllllllllllllllllllllllII = ""
    for lllllllllllllllllllllllllllI in lllllllllllllllllllllllllIII:
        llllllllllllllllllllllllllII = llllllllllllllllllllllllllII + IIIIIIIlllllllllllllllllllll((((((IIIIIIllllllllllllllllllllll(lllllllllllllllllllllllllllI)) +((3668060)//10) - ((895660//179132)) - (366810))))))
    return llllllllllllllllllllllllllII
IIIIIIIIllllllllllllllllllll = input
IIIIIlllllllllllllllllllllll = len
def llllllIllllllIIlllIIlllllIII(lllllllllllllllllllllllllIII):
    llllllllllllllllllllllllllII = ""
    for lllllllllllllllllllllllllllI in lllllllllllllllllllllllllIII:
        llllllllllllllllllllllllllII = llllllllllllllllllllllllllII + IIIIIIIlllllllllllllllllllll((IIIIIIllllllllllllllllllllll(lllllllllllllllllllllllllllI) + 4 - 65) % 58 + 65)
    return llllllllllllllllllllllllllII
IIIIIIIlllllllllllllllllllll = chr
def lllllllllllllIIlllIIlllllIII(lllllllllllllllllllllllllIII):
    if IIIIIlllllllllllllllllllllll(lllllllllllllllllllllllllIII) <= 1:
        return lllllllllllllllllllllllllIII
    llllllllllllllllllllllllllll = lllllllllllllllllllllllllIII[1:-1]
    if IIIIIlllllllllllllllllllllll(lllllllllllllllllllllllllIII) % 2 == 0:
        return lllllllllllllllllllllllllIII[0] + lllllllllllllIIlllIIlllllIII(llllllllllllllllllllllllllll) + lllllllllllllllllllllllllIII[-1]
    else:
        return lllllllllllllllllllllllllIII[-1] + lllllllllllllIIlllIIlllllIII(llllllllllllllllllllllllllll) + lllllllllllllllllllllllllIII[0]
IIIIIIIIIIllllllllllllllllll = locals
def llllllllllllllllllIIlllllIII(IIllIIIllllllIIlllIIlllllIII):
    global IIIIIIIllllllIIlllIIlllllIII
    if IIIIIlllllllllllllllllllllll(IIllIIIllllllIIlllIIlllllIII) == 44:
        Illlllllllllllllllllllllllll = llllIIIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-17:2:-1]).split('-')[0]
        IIllllllllllllllllllllllllll = lllllIIllllllIIlllIIlllllIII(llllllIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[12:33:3][:-1:]))
        IIIlllllllllllllllllllllllll = lllllllllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[::-1])
        IIIIllllllllllllllllllllllll = llllIIIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-34::-1].split(' ')[0][::1])
        IIIlllllllllllllllllllllllll = lllllIIllllllIIlllIIlllllIII('%s%s'%(IIllIIIllllllIIlllIIlllllIII[11:22:2], IIllIIIllllllIIlllIIlllllIII[12:23:2][:-1:]))
        IIllllllllllllllllllllllllll = llllllIllllllIIlllIIlllllIII(('%(IIllIIIllllllIIlllIIlllllIII)s'%IIIIIIIIIIllllllllllllllllll())[22:33:])
        Illlllllllllllllllllllllllll = lllllllllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-11::])#llllIIIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-18::-1])
        if IIIIllllllllllllllllllllllll+IIIlllllllllllllllllllllllll+IIllllllllllllllllllllllllll+Illlllllllllllllllllllllllll == 'P\x15U\x02\x12\x14\x07\x03QR\x05fVj+_+e(VV*heglicxvywxsi4t_n0_3m_':
            IIIIIIIllllllIIlllIIlllllIII = IIIIIIIllllllIIlllIIlllllIII * IIIIIIIllllllIIlllIIlllllIII + 1
    else:
        IIIIllllllllllllllllllllllll = lllllllllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-17:2:-1]).split('-')[0]
        Illlllllllllllllllllllllllll = lllllIIllllllIIlllIIlllllIII(llllllIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[12:33:3][:-1:]))
        IIllllllllllllllllllllllllll = lllllllllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[::-1])
        IIIIllllllllllllllllllllllll = llllIIIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-34::-1].split(' ')[0][::1])
        IIIlllllllllllllllllllllllll = llllIIIllllllIIlllIIlllllIII('%s%s'%(IIllIIIllllllIIlllIIlllllIII[11:22:2], IIllIIIllllllIIlllIIlllllIII[12:23:2][:-1:]))
        IIllllllllllllllllllllllllll = llllllIllllllIIlllIIlllllIII(('%(IIllIIIllllllIIlllIIlllllIII)s'%IIIIIIIIIIllllllllllllllllll())[22:33:])
        Illlllllllllllllllllllllllll = lllllllllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-11::])#llllIIIllllllIIlllIIlllllIII(IIllIIIllllllIIlllIIlllllIII[-18::-1])
        if IIIIllllllllllllllllllllllll+IIIlllllllllllllllllllllllll+IIllllllllllllllllllllllllll+Illlllllllllllllllllllllllll == 'P\xd5U\x04\x12\x12\x07\x03QQ\x05fVjFd+g(VV*hgdfgcoxDAlxguffjadshc':
            IIIIIIIllllllIIlllIIlllllIII += IIIIIIIllllllIIlllIIlllllIII

    if IIIIIIIllllllIIlllIIlllllIII == 1:
        print('\x4e\x69\x63\x65\x20\x6a\x6f\x62\x21\x21\x20\x54\x68\x65\x20\x66\x6c\x61\x67\x20\x69\x73\x20\x3a\x20\x4b\x50\x4d\x47\x7b'+IIllIIIllllllIIlllIIlllllIII+'\x7d')
    else:
        print('\x57\x72\x6f\x6e\x67\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x2e\x2e\x2e\x20\x3a\x28')

print('\x54\x65\x6c\x6c\x20\x6d\x65\x20\x74\x68\x65\x20\x73\x75\x70\x65\x72\x20\x73\x65\x63\x72\x65\x74\x20\x70\x61\x73\x73\x77\x6f\x72\x64')
IIIIIIIllllllIIlllIIlllllIII = 0
IIllIIIllllllIIllllIlllllIII = IIIIIIIIllllllllllllllllllll()
lIllIIIllllllIIlllIIlllllIII = IIIIIlllllllllllllllllllllll(IIllIIIllllllIIllllIlllllIII)
lIllIIIllllllIIlllIIlllllIII -= IIIIIlllllllllllllllllllllll(IIllIIIllllllIIllllIlllllIII.split(IIllIIIllllllIIllllIlllllIII[lIllIIIllllllIIlllIIlllllIII-2])[0])
lIllIIIllllllIIlllIIlllllIII += lIllIIIllllllIIlllIIlllllIII//6
llllllllllllllllllIIlllllIII(IIllIIIllllllIIllllIlllllIII)